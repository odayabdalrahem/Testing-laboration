import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class MyDateTest.
 */
public class MyDateTest
{
    /**
     * Default constructor for test class MyDateTest
     */
    public MyDateTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
    

    @Test
    public void testCompareTo()
    {
        MyDate myDate0 = new MyDate(2000, 3, 3);
        
        //compareTo test 0: trying different days
        MyDate myDate1 = new MyDate(2000, 3, 4);
        assertTrue(myDate0.compareTo(myDate1) == -1); 
        assertTrue(myDate1.compareTo(myDate0) == 1);
        
        //compareTo test 1: trying different months
        MyDate myDate3 = new MyDate(2000, 4, 2);
        assertTrue(myDate0.compareTo(myDate3) == -1); 
        assertTrue(myDate3.compareTo(myDate0) == 1); 
        
        //compareTo test 2: trying different years
        MyDate myDate5 = new MyDate(2001, 3, 7);
        assertTrue(myDate0.compareTo(myDate5) == -1);
        assertTrue(myDate5.compareTo(myDate0) == 1); 
        
        //compareTo test 3: trying the same date
        MyDate myDate6 = new MyDate(2000, 4, 2);
        MyDate myDate7 = new MyDate(2000, 4, 2);
        assertTrue(myDate6.compareTo(myDate7) == 0);
    }
    
    @Test
    public void testEquals()
    {
        MyDate myDate0 = new MyDate(1523, 6, 6);
        MyDate myDate1 = new MyDate(1523, 6, 6);
        assertTrue(myDate0.equals(myDate1));
    }
    
    @Test
    public void testConstructor()
    {   
        //Constructor test 0: Korrekt inmatat datum. Korrekt kod returnerar ingen exception.
        try {
            MyDate myDate0 = new MyDate(2000, 3, 3); //Existerar
        }
        catch (IllegalArgumentException e) {
            assertTrue(false);
        }
        
        //Constructor test 1: För felaktig månad. Korrekt kod returnerar exception.
        try {
            MyDate myDate1 = new MyDate(2001, 13, 3);
        }
        catch (IllegalArgumentException e) {
            assertTrue(true);
        }
        
        //Constructor test 2: För felaktig dag. Korrekt kod returnerar exception.
        try {
            MyDate myDate2 = new MyDate(2001, 3, 32);
        }
        catch (IllegalArgumentException e) {
            assertTrue(true);
        }
        
        //Constructor test 3: Skottår. Korrekt kod returnerar ingen exception.
        try {
            MyDate myDate3 = new MyDate(2016, 2, 29);
        }
        catch (IllegalArgumentException e) {
            assertTrue(false);
        }
        
        //Constructor test 4: Inkorrekt skottår. Korrekt kod returnerar exception.
        try {
            MyDate myDate3 = new MyDate(2017, 2, 29);
        }
        catch (IllegalArgumentException e) {
            assertTrue(true);
        }
        
        //Constructor test 5: Negativt datum. Korrekt kod returnerar exception.
        try {
            MyDate myDate3 = new MyDate(-2017, 2, -29);
        }
        catch (IllegalArgumentException e) {
            assertTrue(true);
        }        
    }
}


